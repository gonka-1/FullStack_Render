package Duoc.Nota.controller;


import Duoc.Nota.models.Nota;
import Duoc.Nota.service.NotaService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;



import java.util.List;

@RestController
@RequestMapping("/api/v1/notas")
public class NotaController {

    private static final Logger log = LoggerFactory.getLogger(NotaController.class);

    @Autowired
    private NotaService notaService;

    @GetMapping
    public ResponseEntity<List<Nota>> listarTodasLasNotas() {
        List<Nota>  notas = notaService.listarTodasLasNotas();
        if  (notas.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(notas);

    }

    @GetMapping("/{id}")
    public ResponseEntity<Nota> buscarPorId (@PathVariable Long id) {
        Nota nota = notaService.buscarPorId(id);
        return ResponseEntity.ok(nota);
    }

    @PostMapping
    public ResponseEntity<Nota> guardarNota(@RequestBody Nota nota){
        Nota notaGuardada = notaService.crearDesdeRequest(nota);
        return ResponseEntity.status(HttpStatus.CREATED).body(notaGuardada);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Nota> actualizaNota(@PathVariable Long id,  @RequestBody Nota nota){
        Nota notaActualizada = notaService.actualizarNota(id, nota);
        return ResponseEntity.ok(notaActualizada);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Nota> eliminarNota(@PathVariable Long id){
        notaService.eliminarNota(id);
        return ResponseEntity.noContent().build();
    }
}
